'use client'

export default function Home() {
  return (
    <div style={{
      minHeight: '100vh',
      background: 'linear-gradient(135deg, #1e3a5f 0%, #2d5a87 100%)',
      fontFamily: 'system-ui, -apple-system, sans-serif',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      padding: '2rem'
    }}>
      <div style={{
        background: 'white',
        borderRadius: '20px',
        padding: '3rem',
        maxWidth: '600px',
        textAlign: 'center',
        boxShadow: '0 25px 50px rgba(0,0,0,0.3)'
      }}>
        <div style={{ fontSize: '4rem', marginBottom: '1rem' }}>📄</div>
        
        <h1 style={{ fontSize: '1.8rem', color: '#1e3a5f', marginBottom: '0.5rem' }}>
          Monografia Atualizada
        </h1>
        
        <p style={{ color: '#6b7280', marginBottom: '2rem', fontSize: '1rem' }}>
          A INFLUÊNCIA DA LÍNGUA MATERNA NO APRENDIZADO DO PORTUGUÊS<br/>
          <strong>Escola Primaria de Canjanda</strong>
        </p>

        <div style={{ display: 'flex', flexDirection: 'column', gap: '1rem', marginBottom: '2rem' }}>
          <a 
            href="/Monografia_Nelsa_Atualizada.docx"
            style={{
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              gap: '0.75rem',
              background: '#2563eb',
              color: 'white',
              padding: '1.2rem 2rem',
              borderRadius: '12px',
              fontSize: '1.1rem',
              fontWeight: 'bold',
              textDecoration: 'none'
            }}
          >
            <span style={{ fontSize: '1.5rem' }}>📄</span>
            BAIXAR WORD (.docx)
          </a>
          
          <a 
            href="/Monografia_Nelsa_Atualizada.pdf"
            style={{
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              gap: '0.75rem',
              background: '#dc2626',
              color: 'white',
              padding: '1.2rem 2rem',
              borderRadius: '12px',
              fontSize: '1.1rem',
              fontWeight: 'bold',
              textDecoration: 'none'
            }}
          >
            <span style={{ fontSize: '1.5rem' }}>📕</span>
            BAIXAR PDF
          </a>
        </div>

        <div style={{
          background: '#f0fdf4',
          borderRadius: '12px',
          padding: '1rem',
          fontSize: '0.85rem',
          color: '#166534',
          textAlign: 'left'
        }}>
          <strong>✅ Atualizações:</strong><br/>
          • 40 alunos | 1 professor<br/>
          • Escola Primaria de Canjanda<br/>
          • Bairro Matundo, Unidade Nhaufa<br/>
          • Supervisor: Domingos Ailande
        </div>
      </div>
    </div>
  )
}
